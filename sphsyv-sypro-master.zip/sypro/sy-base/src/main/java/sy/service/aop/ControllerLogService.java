package sy.service.aop;

import sy.model.aop.ControllerLog;
import sy.service.base.BaseService;

/**
 * ControllerLogService
 * 
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface ControllerLogService extends BaseService<ControllerLog, Long> {

}