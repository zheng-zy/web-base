package sy.dao.demo;

import sy.dao.base.BaseDao;
import sy.model.demo.DemoA;

/**
 * DemoADao接口
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoADao extends BaseDao<DemoA, Long> {

}