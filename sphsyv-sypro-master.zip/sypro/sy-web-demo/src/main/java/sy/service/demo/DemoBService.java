package sy.service.demo;

import sy.model.demo.DemoB;
import sy.service.base.BaseService;

/**
 * DemoBService
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoBService extends BaseService<DemoB, Long> {

}