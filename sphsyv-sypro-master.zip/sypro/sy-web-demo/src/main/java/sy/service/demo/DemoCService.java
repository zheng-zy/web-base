package sy.service.demo;

import sy.model.demo.DemoC;
import sy.service.base.BaseService;

/**
 * DemoCService
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoCService extends BaseService<DemoC, Long> {

}