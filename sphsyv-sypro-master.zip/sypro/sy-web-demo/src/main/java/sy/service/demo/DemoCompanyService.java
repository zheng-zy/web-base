package sy.service.demo;

import sy.model.demo.DemoCompany;
import sy.service.base.BaseService;

/**
 * DemoCompanyService
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoCompanyService extends BaseService<DemoCompany, Long> {

}