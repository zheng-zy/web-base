package sy.service.demo;

import sy.service.base.BaseService;

/**
 * http://git.oschina.net/sphsyv/sypro
 * 
 * @author 孙宇
 *
 */
public interface DemoInitService extends BaseService {

	/**
	 * 初始化测试数据
	 */
	public void init();

}
