package sy.service.demo;

import sy.model.demo.DemoA;
import sy.service.base.BaseService;

/**
 * DemoAService
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoAService extends BaseService<DemoA, Long> {

}