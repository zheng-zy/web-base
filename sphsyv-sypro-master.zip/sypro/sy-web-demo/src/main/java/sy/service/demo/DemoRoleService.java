package sy.service.demo;

import sy.model.demo.DemoRole;
import sy.service.base.BaseService;

/**
 * DemoRoleService
 *
 * http://git.oschina.net/sphsyv/sypro
 *
 * 由代码生成器生成
 *
 * @author 孙宇
 *
 */
public interface DemoRoleService extends BaseService<DemoRole, Long> {

}